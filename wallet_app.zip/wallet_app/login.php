<?php
// Start the session
session_start();

// Include the database configuration
require_once 'config.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        // Prepare the SQL query
        $query = $db->prepare("SELECT * FROM users WHERE email = :email");

        // Bind the parameter
        $query->bindParam(':email', $email);

        // Execute the query
        $query->execute();

        // Fetch the user data
        $user = $query->fetch(PDO::FETCH_ASSOC);

        // Verify the password
        if ($user && password_verify($password, $user['password'])) {
            // Set the user ID in the session
            $_SESSION['user_id'] = $user['id'];

            // Redirect to the dashboard
            header('Location: dashboard.php');
            exit;
        } else {
            $loginError = 'Invalid email or password';
        }
    } catch (PDOException $e) {
        $loginError = 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .auth-container {
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f8f9fa;
        }

        .auth-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .auth-container form {
            margin-bottom: 15px;
        }

        .auth-container form label {
            font-weight: bold;
            color: #555;
        }

        .auth-container form button {
            width: 100%;
            background-color: #000;
            color: #fff;
        }

        .auth-container .alert {
            margin-bottom: 15px;
        }

        .auth-container .login-form-title {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .auth-container .login-form-links {
            text-align: center;
            margin-top: 20px;
        }
        
        .auth-container .login-form-links a {
            color: #555;
        }
        
        .auth-container .login-form-links a:hover {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-container">
                    <h2 class="login-form-title">Login</h2>
                    <?php if (isset($loginError)) { ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $loginError; ?>
                        </div>
                    <?php } ?>
                    <form action="login.php" method="post">
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                    </form>
                    <div class="login-form-links">
                        <a href="forgot_password.php">Forgot password?</a>
                        <span> | </span>
                        <a href="register.php">Create an account</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
