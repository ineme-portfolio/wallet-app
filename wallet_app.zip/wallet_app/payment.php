<?php
// Initialize the payment
function initializePayment($amount, $email, $callbackUrl)
{
    $ch = curl_init('https://api.paystack.co/transaction/initialize');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'amount' => $amount * 100, // Paystack requires amount in kobo (multiply by 100)
        'email' => $email,
        'callback_url' => $callbackUrl,
    ]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer sk_test_ceba141e747f2014524bbbead8127ed5b62c7b4c', // Replace with your Paystack Secret Key
        'Content-Type: application/x-www-form-urlencoded',
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    return $data['data']['authorization_url'];
}

// Verify the payment
function verifyPayment($transactionReference)
{
    $ch = curl_init('https://api.paystack.co/transaction/verify/' . $transactionReference);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer sk_test_ceba141e747f2014524bbbead8127ed5b62c7b4c', // Replace with your Paystack Secret Key
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    return $data['data'];
}
?>
