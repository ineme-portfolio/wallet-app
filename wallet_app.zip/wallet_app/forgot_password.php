<?php
// Include the database configuration
require_once 'config.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    try {
        // Check if the email exists in the database
        $query = $db->prepare("SELECT * FROM users WHERE email = :email");
        $query->bindParam(':email', $email);
        $query->execute();
        $user = $query->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Generate a unique token for password reset
            $token = bin2hex(random_bytes(32));

            // Store the token and its expiration time in the database
            $expirationTime = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $query = $db->prepare("UPDATE users SET reset_token = :token, reset_token_expiration = :expiration WHERE id = :id");
            $query->bindParam(':token', $token);
            $query->bindParam(':expiration', $expirationTime);
            $query->bindParam(':id', $user['id']);
            $query->execute();

            // Send the password reset link to the user's email address
            $to = $email;
            $subject = 'Password Reset';
            $message = 'Click the following link to reset your password: ' . 'http://example.com/reset_password.php?token=' . $token . '&id=' . $user['id'];
            $headers = 'From: your_email@example.com' . "\r\n" .
                       'Reply-To: your_email@example.com' . "\r\n" .
                       'X-Mailer: PHP/' . phpversion();

            if (mail($to, $subject, $message, $headers)) {
                // Display success message
                $successMessage = 'Please check your email for further instructions.';
            } else {
                // Error sending email
                $errorMessage = 'Error sending email. Please try again later.';
            }
        } else {
            // Email does not exist in the database
            $errorMessage = 'The provided email address is not registered.';
        }
    } catch (PDOException $e) {
        $errorMessage = 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .auth-container {
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f8f9fa;
        }

        .auth-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .auth-container form {
            margin-bottom: 15px;
        }

        .auth-container form label {
            font-weight: bold;
            color: #555;
        }

        .auth-container form button {
            width: 100%;
            background-color: #000;
            color: #fff;
        }

        .auth-container .alert {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-container">
                    <h2>Forgot Password</h2>
                    <?php if (isset($successMessage)) { ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $successMessage; ?>
                        </div>
                    <?php } ?>
                    <?php if (isset($errorMessage)) { ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $errorMessage; ?>
                        </div>
                    <?php } ?>
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
