<?php

require_once 'payment.php';

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get the user ID from the session
$userId = $_SESSION['user_id'];

// Include the database configuration
require_once 'config.php';

try {
    // Prepare the SQL query
    $query = $db->prepare("SELECT * FROM users WHERE id = :id");

    // Bind the parameter
    $query->bindParam(':id', $userId);

    // Execute the query
    $query->execute();

    // Fetch the user data
    $user = $query->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
    exit;
}


try {
    // Prepare the SQL query to fetch payment data
    $query = $db->prepare("SELECT * FROM payments WHERE email = :email");

    // Bind the parameter
    $query->bindParam(':email', $user['email']);

    // Execute the query
    $query->execute();

    // Fetch the payment data
    $payments = $query->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
    exit;
}


// Process the payment initiation request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = $_POST['amount'];
    $email = $user['email'];

    // Initialize the payment
    $authorizationUrl = initializePayment($amount, $email, 'http://localhost/wallet_app/callback.php');

    // Redirect the user to the Paystack payment page
    header('Location: ' . $authorizationUrl);
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            padding-top: 70px;
        }
        
        .navbar {
            background-color: #000;
        }
        
        .navbar-brand {
            color: #fff;
        }
        
        .navbar-nav .nav-link {
            color: #fff;
        }
        
        .container {
            display: grid;
            grid-template-columns: 1fr;
            grid-gap: 20px;
        }
        
        @media (min-width: 768px) {
            .container {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        .user-info {
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f8f9fa;
            padding: 20px;
        }
        
        .user-info h2 {
            margin-bottom: 20px;
        }
        
        .user-info p {
            margin-bottom: 10px;
        }
        
        .transaction-table {
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f8f9fa;
        }
        
        .transaction-table h5 {
            margin-top: 0;
            padding: 10px;
            background-color: #000;
            color: #fff;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        
        .transaction-table table {
            width: 100%;
            margin-bottom: 0;
        }
        
        .transaction-table table th,
        .transaction-table table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        
        .transaction-table table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: bold;
            text-align: left;
        }
        
        .transaction-table table tbody tr:hover {
            background-color: #f1f1f1;
        }
        
        .wallet-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
        }
        
        .wallet-card h5 {
            margin-bottom: 20px;
        }
        
        .wallet-card h6 {
            margin-bottom: 10px;
        }
        
        .wallet-card p {
            margin-bottom: 20px;
        }
        
        .wallet-card form {
            margin-bottom: 20px;
        }
        
        .wallet-card form button {
            width: 100%;
            background-color: #000;
            color: #fff;
            transition: background-color 0.3s ease;
        }
        
        .wallet-card form button:hover {
            background-color: #000;
        }
        
        .logout-button {
            background-color: #f00;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <a class="navbar-brand" href="#">User Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="withdrawal_dashboard.php">Withdraw Fund</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
                <li class="nav-item">
                    <form action="logout.php" method="post">
                        <button type="submit" class="btn btn-danger logout-button">Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    </nav>
    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-info">
                    <h2>Welcome, <?php echo $user['name']; ?>!</h2>
                    <p>Email: <?php echo $user['email']; ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card transaction-table">
                    <div class="card-body">
                        <h5>Add Fund Transaction History</h5>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Reference</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment) : ?>
                                    <tr>
                                        <td><?php echo $payment['created_at']; ?></td>
                                        <td><?php echo $payment['amount']; ?></td>
                                        <td><?php echo $payment['transaction_reference']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card wallet-card">
                    <div class="card-header">
                        <h5>Wallet</h5>
                    </div>
                    <div class="card-body">
                        <h6>Account Balance:</h6>
                        <p>$ <?php echo $user['wallet_balance'] ?></p>
                        <h6>Deposit:</h6>
                        <form action="dashboard.php" method="post">
                            <div class="form-group">
                                <input type="number" class="form-control" name="amount" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Deposit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
