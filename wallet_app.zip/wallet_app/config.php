<?php
// Database configuration
$dbHost = 'localhost';
$dbName = 'wallet_app';
$dbUser = 'root';
$dbPass = '';

// Create a new PDO instance
$db = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);

// Set PDO error mode to exception
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
