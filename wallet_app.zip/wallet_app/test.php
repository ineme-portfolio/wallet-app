<?php
 <div class="container">
 <h2>Welcome, <?php echo $user['name']; ?>!</h2>
 <p>Email: <?php echo $user['email']; ?></p>
 </div>