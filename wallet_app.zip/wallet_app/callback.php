<?php
require_once 'payment.php';

session_start();

$userId = $_SESSION['user_id'];

// Retrieve the transaction reference from the callback request
$transactionReference = $_GET['reference'];

// Verify the payment
$paymentData = verifyPayment($transactionReference);

// Check if the payment is successful
if ($paymentData['status'] === 'success') {
    $amount = $paymentData['amount'] / 100; // Convert amount from kobo to naira

    // Get the user's email from the payment data
    $email = $paymentData['customer']['email'];

    // Get the user's current wallet balance from the database
    $pdo = new PDO('mysql:host=localhost;dbname=wallet_app', 'root', '');
    $stmt = $pdo->prepare('SELECT wallet_balance FROM users WHERE id = :user_id');
    $stmt->bindParam(':user_id', $userId); // Replace with the user ID of the logged-in user
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $currentBalance = $row['wallet_balance'];

    // Update the wallet balance in the database
    $newBalance = $currentBalance + $amount;
    $stmt = $pdo->prepare('UPDATE users SET wallet_balance = :new_balance WHERE id = :user_id');
    $stmt->bindParam(':new_balance', $newBalance);
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();

     // Insert the payment details into the database
     $stmt = $pdo->prepare('INSERT INTO payments (email, transaction_reference, amount) VALUES (:email, :transaction_reference, :amount)');
     $stmt->bindParam(':email', $email);
     $stmt->bindParam(':transaction_reference', $transactionReference);
     $stmt->bindParam(':amount', $amount);
     $stmt->execute();

    // Redirect the user to the dashboard or display a success message
    header('Location: http://localhost/wallet_app/dashboard.php');
    exit;
} else {
    // Redirect the user to the dashboard or display an error message
    header('Location: http://localhost/wallet_app/dashboard.php');
    exit;
}
?>
