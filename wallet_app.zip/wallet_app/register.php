<?php
// Include the database configuration
require_once 'config.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare the SQL query
        $query = $db->prepare("INSERT INTO users (name, email, password) VALUES (:name, :email, :password)");

        // Bind the parameters
        $query->bindParam(':name', $name);
        $query->bindParam(':email', $email);
        $query->bindParam(':password', $hashedPassword);

        // Execute the query
        $query->execute();

        $registrationSuccess = 'Registration successful';
    } catch (PDOException $e) {
        $registrationError = 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .auth-container {
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f8f9fa;
        }

        .auth-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .auth-container form {
            margin-bottom: 15px;
        }

        .auth-container form label {
            font-weight: bold;
            color: #555;
        }

        .auth-container form button {
            width: 100%;
            background-color: #000;
            color: #fff;
        }

        .auth-container .alert {
            margin-bottom: 15px;
        }

        .auth-container .register-form-title {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .auth-container .register-form-links {
            text-align: center;
            margin-top: 20px;
        }
        
        .auth-container .register-form-links a {
            color: #555;
        }
        
        .auth-container .register-form-links a:hover {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-container">
                    <h2 class="register-form-title">Register</h2>
                    <?php if (isset($registrationSuccess)) { ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $registrationSuccess; ?>
                        </div>
                    <?php } ?>
                    <?php if (isset($registrationError)) { ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $registrationError; ?>
                        </div>
                    <?php } ?>
                    <form action="register.php" method="post">
                        <div class="form-group">
                            <label>Name:</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Register</button>
                    </form>
                    <div class="register-form-links">
                        <a href="login.php">Already have an account? Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
