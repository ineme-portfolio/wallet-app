<?php

// it not useful for now.
// Function to process withdrawal
function withdrawFunds($amount, $userId, $db)
{
    // Get the user's current wallet balance from the database
    $stmt = $db->prepare('SELECT wallet_balance FROM users WHERE id = :user_id');
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $currentBalance = $row['wallet_balance'];

    // Check if the user has sufficient balance for withdrawal
    if ($amount <= $currentBalance) {
        // Calculate the new wallet balance after withdrawal
        $newBalance = $currentBalance - $amount;

        // Update the wallet balance in the database
        $stmt = $db->prepare('UPDATE users SET wallet_balance = :new_balance WHERE id = :user_id');
        $stmt->bindParam(':new_balance', $newBalance);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();

        // Display a success message to the user
        echo 'Withdrawal successful! Wallet balance updated.';
    } else {
        // Display an error message if the user doesn't have sufficient balance
        echo 'Insufficient balance for withdrawal.';
    }
}
?>
