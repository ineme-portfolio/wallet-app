<?php
session_start();

require_once "config.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to the login page if the user is not logged in
    exit();
}

// Get the user ID from the session
$userId = $_SESSION['user_id'];

try {
  // Prepare the SQL query
  $query = $db->prepare("SELECT * FROM users WHERE id = :id");

  // Bind the parameter
  $query->bindParam(':id', $userId);

  // Execute the query
  $query->execute();

  // Fetch the user data
  $user = $query->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  echo 'Error: ' . $e->getMessage();
  exit;
}

// Retrieve the user ID from the session
$userID = $_SESSION['user_id'];

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Withdrawal System</title>
    <!-- Include Bootstrap CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            padding-top: 70px; /* Add top padding to account for fixed navbar */
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .navbar {
            background-color: #000;
        }
        
        .navbar-brand {
            color: #fff;
        }
        
        .navbar-nav .nav-link {
            color: #fff;
        }

        .grid-container {
            display: grid;
            grid-gap: 20px;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        }

        .user-info,
        .withdrawal-form,
        .withdrawal-history {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 20px;
        }

        .user-info h2,
        .withdrawal-form h2,
        .withdrawal-history h2 {
            margin-top: 0;
        }

        .withdrawal-form form {
            margin-bottom: 0;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 0;
            margin-top: 3rem;
        }

        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }

        table {
            width: 100%;
        }

        table th,
        table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            font-weight: bold;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <a class="navbar-brand" href="#">User Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Add Fund</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
                <li class="nav-item">
                    <form action="logout.php" method="post">
                        <button type="submit" class="btn btn-danger logout-button">Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    </nav>
<div class="container">
    <div class="grid-container">
        <div class="user-info">
        <?php
            // Retrieve the user's current wallet balance and email from the database
            try {
                $stmt = $db->prepare("SELECT wallet_balance, email FROM users WHERE id = ?");
                $stmt->execute([$userID]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $walletBalance = $row['wallet_balance'];
                $userEmail = $row['email'];
            } catch (PDOException $e) {
                die("Failed to retrieve user's wallet balance: " . $e->getMessage());
            }
            ?>
            <h2>Welcome, <?php echo $user['name']; ?>!</h2>
            <p>Email: <?php echo $userEmail; ?></p>
            <p>Wallet Balance: <?php echo $walletBalance; ?></p>
        </div>

        <div class="withdrawal-form">
            <h2>Withdrawal Form</h2>

            <?php
               // Check if the withdrawal amount is submitted
                          // Check if the withdrawal amount is submitted
            if (isset($_POST['amount'])) {
              $amount = $_POST['amount'];

              // Validate the withdrawal amount
              if (!empty(trim($amount))) {
                  // Check if the user has sufficient balance
                  if ($walletBalance >= $amount) {
                      // Deduct the withdrawal amount from the wallet balance
                      $updatedBalance = $walletBalance - $amount;

                      // Update the user's wallet balance in the database
                      try {
                          $stmt = $db->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
                          $stmt->execute([$updatedBalance, $userID]);
                      } catch (PDOException $e) {
                          die("Failed to update user's wallet balance: " . $e->getMessage());
                      }

                      // Insert the withdrawal record into the database
                      try {
                          $stmt = $db->prepare("INSERT INTO withdrawals (user_id, email, amount, timestamp) VALUES (?, ?, ?, NOW())");
                          $stmt->execute([$userID, $userEmail, $amount]);

                          // Redirect to a success page or display a success message
                          //header('Location: success.php');
                          echo '<div class="alert alert-success">Withdrawal successful.</div>';
                          // Perform a redirect to avoid form resubmission
                          header('Location: withdrawal_dashboard.php');
                          exit();
                      } catch (PDOException $e) {
                          die("Withdrawal failed: " . $e->getMessage());
                      }
                  } else {
                      // Display an error message for insufficient balance
                      echo '<div class="alert alert-danger">Insufficient balance. Please enter a lower amount.</div>';
                  }
              } else {
                  // Display an error message for empty withdrawal amount
                  echo '<div class="alert alert-danger">Please enter a withdrawal amount.</div>';
              }
            }


            ?>

            <form action="withdrawal_dashboard.php" method="POST">
                <label for="amount" class="my-2">Withdraw Amount:</label>
                <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="number" name="amount" id="amount" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-dark my-2">Withdraw</button>
            </form>
        </div>

        <div class="withdrawal-history">

          <?php
                    // Define the number of withdrawals to display per page
          $perPage = 5;

          // Fetch total number of withdrawals
          try {
              $stmt = $db->prepare("SELECT COUNT(*) AS total FROM withdrawals WHERE user_id = ?");
              $stmt->execute([$userID]);
              $row = $stmt->fetch(PDO::FETCH_ASSOC);
              $totalWithdrawals = $row['total'];
          } catch (PDOException $e) {
              die("Failed to retrieve total withdrawals: " . $e->getMessage());
          }

          // Calculate the total number of pages
          $totalPages = ceil($totalWithdrawals / $perPage);

          // Get the current page number from the query string
          $current = isset($_GET['page']) ? $_GET['page'] : 1;

          // Calculate the offset for the query
          $offset = ($current - 1) * $perPage;

          // Fetch withdrawals for the current page
          try {
              $stmt = $db->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?, ?");
              $stmt->bindValue(1, $userID, PDO::PARAM_INT);
              $stmt->bindValue(2, $offset, PDO::PARAM_INT);
              $stmt->bindValue(3, $perPage, PDO::PARAM_INT);
              $stmt->execute();
              $withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);
          } catch (PDOException $e) {
              die("Failed to retrieve withdrawals: " . $e->getMessage());
          }
          ?>

          <div class="withdrawal-history">
              <h2>Withdrawal History</h2>
              <table>
                  <thead>
                      <tr>
                          <th>Date</th>
                          <th>Amount</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($withdrawals as $withdrawal) { ?>
                          <tr>
                              <td><?php echo $withdrawal['timestamp']; ?></td>
                              <td><?php echo '$' . $withdrawal['amount']; ?></td>
                          </tr>
                      <?php } ?>
                  </tbody>
              </table>

              <!-- Pagination links -->
              <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                    <li class="page-item <?php echo ($i == $current) ? 'active' : ''; ?>">
                        <a class="page-link <?php echo ($i == $current) ? 'btn-dark' : 'btn-dark'; ?>" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php } ?>
              </ul>
          </div>

          
        </div>
    </div>
</div>

<!-- Include Bootstrap JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
