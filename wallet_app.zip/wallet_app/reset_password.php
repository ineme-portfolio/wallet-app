
<?php
// Include the database configuration
require_once 'config.php';

// Check if the token and user ID are present in the query string
if (isset($_GET['token']) && isset($_GET['id'])) {
    $token = $_GET['token'];
    $userId = $_GET['id'];

    // Verify the token and user ID in the database
    $query = $db->prepare("SELECT * FROM users WHERE id = :id AND reset_token = :token AND reset_token_expiration >= NOW()");
    $query->bindParam(':id', $userId);
    $query->bindParam(':token', $token);
    $query->execute();
    $user = $query->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Handle the form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = $_POST['password'];
            $confirmPassword = $_POST['confirm_password'];

            if ($password === $confirmPassword) {
                // Update the user's password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $query = $db->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_token_expiration = NULL WHERE id = :id");
                $query->bindParam(':password', $hashedPassword);
                $query->bindParam(':id', $user['id']);
                $query->execute();

                // Display success message
                $successMessage = 'Your password has been reset successfully.';
            } else {
                $errorMessage = 'Passwords do not match.';
            }
        }
    } else {
        // Invalid or expired token
        $errorMessage = 'Invalid or expired token.';
    }
} else {
    // Token or user ID not present in the query string
    $errorMessage = 'Invalid request.';
}
?>

<!-- The rest of the reset_password.php HTML code remains the same -->

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .auth-container {
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f8f9fa;
        }

        .auth-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .auth-container form {
            margin-bottom: 15px;
        }

        .auth-container form label {
            font-weight: bold;
            color: #555;
        }

        .auth-container form button {
            width: 100%;
            background-color: #000;
            color: #fff;
        }

        .auth-container .alert {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-container">
                    <h2>Reset Password</h2>
                    <?php if (isset($errorMessage)) { ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $errorMessage; ?>
                        </div>
                    <?php } ?>
                    <?php if (isset($successMessage)) { ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $successMessage; ?>
                        </div>
                    <?php } ?>
                    <form action="" method="post">
                        <div class="form-group">
                            <label>New Password:</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password:</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Reset Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
